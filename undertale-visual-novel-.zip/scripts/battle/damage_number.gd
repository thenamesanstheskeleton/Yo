extends Control

# =====================================================
#  damage_number.gd
#  Attach to: DamageNumber (Control) — damage_number.tscn
#
#  Spawned by fight_meter after hit confirm.
#  Shows zone hit text (PERFECT / GOOD / OK / WEAK / MISS)
#  OR a raw damage number — rises, drifts, fades out.
#
#  ✅ FIX: node name corrected to "ShadowLabel" (was "shadowlabel")
#  Make sure tscn node is renamed to match.
# =====================================================

@onready var shadow_label : Label = $ShadowLabel   # ✅ capital S — fix case in tscn
@onready var main_label   : Label = $MainLabel

@export var rise_speed  : float = 90.0
@export var fade_time   : float = 0.8
@export var drift_speed : float = 12.0

var _time : float = 0.0


# Called by fight_meter with zone string e.g. "PERFECT!"
func setup_text(text: String) -> void:
	_apply_labels(text)


# Fallback — called with raw int damage if setup_text not used
func setup(amount: int) -> void:
	_apply_labels(str(amount))


func _apply_labels(text: String) -> void:
	if main_label:
		main_label.text = text
		main_label.add_theme_color_override("font_color", Color(0.75, 0.05, 0.05))
		main_label.add_theme_constant_override("outline_size", 4)
	if shadow_label:
		shadow_label.text = text
		shadow_label.add_theme_color_override("font_color", Color(0.08, 0.0, 0.0))
		# Offset shadow slightly for depth
		shadow_label.position = Vector2(2, 2)
	modulate.a = 1.0
	scale      = Vector2.ONE
	_time      = 0.0


func _process(delta: float) -> void:
	_time += delta
	position.y -= rise_speed * delta
	position.x += drift_speed * delta

	var t : float = clamp(_time / fade_time, 0.0, 1.0)
	modulate.a = 1.0 - t
	scale      = Vector2.ONE * (1.0 + (0.12 * (1.0 - t)))

	if _time >= fade_time:
		queue_free()
