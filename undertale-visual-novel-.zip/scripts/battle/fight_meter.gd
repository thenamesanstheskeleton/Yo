extends Control

@onready var bar_one  : TextureRect     = $BarOne
@onready var bar_two  : TextureRect     = $BarTwo
@onready var meter_bar: TextureRect     = $MeterBar
@onready var anim     : AnimationPlayer = $MeterAnim

@export var damage_popup_scene: PackedScene

var frozen: bool = false
var _bar_width: float = 546.0


# ── Zone thresholds ──
const CENTER: float       = 0.5
const PERFECT_HALF: float = 0.015
const GREEN_HALF: float   = 0.12
const YELLOW_HALF: float  = 0.32
const RED_HALF: float     = 0.47

# Multipliers
const MULT_PERFECT: float = 1.00
const MULT_GREEN: float   = 0.75
const MULT_YELLOW: float  = 0.40
const MULT_RED: float     = 0.15
const MULT_MISS: float    = 0.00


func _ready() -> void:
	bar_two.visible = false
	call_deferred("_measure_width")
	anim.play("slide_loop")


func _measure_width() -> void:
	if meter_bar and meter_bar.size.x > 0.0:
		_bar_width = meter_bar.size.x


func _process(_delta: float) -> void:
	if frozen:
		return
	bar_two.global_position = bar_one.global_position


func _input(event: InputEvent) -> void:
	if not visible:
		return

	var pressed: bool = false

	if event is InputEventScreenTouch and event.pressed:
		pressed = true
	elif event is InputEventKey and event.pressed:
		if event.keycode == KEY_Z or event.keycode == KEY_ENTER:
			pressed = true
	elif event is InputEventMouseButton and event.pressed:
		pressed = true

	if pressed:
		trigger_hit()


func trigger_hit() -> void:
	if frozen:
		return

	frozen = true

	anim.speed_scale = 0.0
	bar_two.visible = true
	bar_two.position = bar_one.position

	var x: float = bar_one.position.x
	var ratio: float = clamp(x / _bar_width, 0.0, 1.0)
	var multi: float = _get_multiplier(ratio)

	await start_flick()

	spawn_damage_number(multi)

	var manager: Node = _find_battle_manager()
	if manager and manager.has_method("on_fight_confirmed"):
		manager.on_fight_confirmed(multi)

	hide_meter()


func start_flick() -> void:
	for i in range(5):
		bar_one.visible = not bar_one.visible
		bar_two.visible = not bar_two.visible
		await get_tree().create_timer(0.03).timeout

	bar_one.visible = true
	bar_two.visible = false


func spawn_damage_number(multiplier: float) -> void:
	if damage_popup_scene == null:
		return

	var popup: Node = damage_popup_scene.instantiate()
	get_tree().current_scene.add_child(popup)
	popup.global_position = bar_one.global_position + Vector2(0, 70)

	var zone_text: String

	if multiplier >= MULT_PERFECT:
		zone_text = "PERFECT!"
	elif multiplier >= MULT_GREEN:
		zone_text = "GOOD"
	elif multiplier >= MULT_YELLOW:
		zone_text = "OK"
	elif multiplier >= MULT_RED:
		zone_text = "WEAK"
	else:
		zone_text = "MISS"

	if popup.has_method("setup_text"):
		popup.setup_text(zone_text)
	elif popup.has_method("setup"):
		popup.setup(0)


func hide_meter() -> void:
	visible = false


func reset_meter() -> void:
	frozen = false
	anim.speed_scale = 1.0
	bar_two.visible = false
	bar_one.visible = true

	bar_one.position = Vector2.ZERO
	bar_two.position = Vector2.ZERO

	anim.play("slide_loop")

	if meter_bar and meter_bar.size.x > 0.0:
		_bar_width = meter_bar.size.x


func _get_multiplier(ratio: float) -> float:
	var dist: float = abs(ratio - CENTER)

	if dist <= PERFECT_HALF:
		return MULT_PERFECT
	elif dist <= GREEN_HALF:
		return MULT_GREEN
	elif dist <= YELLOW_HALF:
		return MULT_YELLOW
	elif dist <= RED_HALF:
		return MULT_RED
	else:
		return MULT_MISS


func _find_battle_manager() -> Node:
	var node: Node = get_parent()

	while node:
		if node.has_method("on_fight_confirmed"):
			return node
		node = node.get_parent()

	return null
