extends Control

# =====================================================
#  Chapter2.gd
#  Controls Chapter 2 — "A Morning in Snowdin"
#
#  Architecture overview:
#    ┌─────────────────────────────────────────────┐
#    │  VNEngine     — dialogue / narration / choices
#    │  ExploreLayer — room hotspots + hover system
#    │  PanSystem    — horizontal scroll of BG+hotspots
#    │  InventoryM   — item stub (pancakes etc.)
#    │  BlizzardFX   — upgraded snowfall particles
#    │  CutsceneCtrl — waterfall flashback handler
#    └─────────────────────────────────────────────┘
#
#  PAN SYSTEM OVERVIEW:
#    Background images are landscape ~16:9.
#    Viewport is portrait 1080x1920.
#    Images are rendered at full height (scale = 1920/img_h),
#    making rendered width ~3413px.
#    A pan offset (0 → max_pan) shifts the BG + hotspot
#    container left/right so the player can explore the
#    full room by moving their finger/cursor to screen edges.
#
#    BG node:        position.x = -pan_offset
#    HotspotRoot:    position.x = -pan_offset  (moves with BG)
#    DialogueLayer:  pinned to screen           (never pans)
#
#  HOTSPOT COORDINATES:
#    All hotspot positions are stored in IMAGE-SPACE pixels.
#    The pan system converts them to screen space each frame:
#      screen_x = image_x * scale_factor - pan_offset
#    Hotspot nodes use position= (not anchors) so they move
#    cleanly with the background.
#
#  PAN TRIGGER (mobile):
#    Left  20% of screen → pan left
#    Right 20% of screen → pan right
#    Only active during explore mode (not during dialogue)
# =====================================================

const CHAPTER_DATA = preload("res://scripts/data/Chapter2.gd")

# ── VNEngine node refs ─────────────────────────────────
@onready var engine          : Node            = $VNEngine
@onready var bg_rect         : TextureRect     = $Background
@onready var char_center     : TextureRect     = $CharCenter
@onready var char_left       : TextureRect     = $CharLeft
@onready var char_right      : TextureRect     = $CharRight
@onready var dialog_box      : ColorRect       = $DialogueLayer/DialogBox
@onready var name_box        : ColorRect       = $DialogueLayer/NameBox
@onready var name_label      : Label           = $DialogueLayer/NameLabel
@onready var dialog_text     : RichTextLabel   = $DialogueLayer/DialogText
@onready var next_arrow      : Label           = $DialogueLayer/NextArrow
@onready var choice_cont     : VBoxContainer   = $DialogueLayer/ChoiceContainer
@onready var black_screen    : ColorRect       = $BlackScreenTransition
@onready var fade_player     : AnimationPlayer = $BlackScreenTransition/FadePlayer
@onready var chapter_events  : AnimationPlayer = $ChapterEvents

# ── Exploration layer ──────────────────────────────────
@onready var explore_layer   : CanvasLayer     = $ExploreLayer

# ── Room hotspot containers ────────────────────────────
@onready var room_papyrus    : Control         = $ExploreLayer/Room_PapyrusRoom
@onready var room_living     : Control         = $ExploreLayer/Room_LivingRoom
@onready var room_kitchen    : Control         = $ExploreLayer/Room_Kitchen

# ── Blizzard FX ────────────────────────────────────────
@onready var blizzard_fx     : Node            = $BlizzardFX

# ── Cutscene overlay ───────────────────────────────────
@onready var cutscene_layer  : CanvasLayer     = $CutsceneLayer
@onready var bonedows_inst   : Node            = null

# ── Yesterday title ────────────────────────────────────
@onready var yesterday_label : Label           = $BlackScreenTransition/YesterdayLabel

# ── Yesterday dramatic title state ─────────────────────
var _yesterday_tween: Tween = null
var _yesterday_dots: int = 0

# ── Pan edge indicators (optional visual hints) ────────
@onready var pan_hint_left   : Control         = $PanHintLeft
@onready var pan_hint_right  : Control         = $PanHintRight

# =====================================================
#  PAN SYSTEM CONSTANTS
#  Derived from: scale = 1920 / img_height
#  rendered_w = img_width * scale
#  max_pan = rendered_w - 1080
# =====================================================

const VIEWPORT_W : float = 1080.0
const VIEWPORT_H : float = 1920.0

# Per-room pan data  { scale, rendered_w, max_pan, start_pan }
const ROOM_PAN : Dictionary = {
	"papyrus_room": {
		"scale":      2.6667,
		"rendered_w": 3413.3,
		"max_pan":    2333.3,
		"start_pan":  1166.7,   # center of image on load
	},
	"living_room": {
		"scale":      2.6667,
		"rendered_w": 3413.3,
		"max_pan":    2333.3,
		"start_pan":  1166.7,
	},
	"kitchen": {
		"scale":      2.5000,
		"rendered_w": 3412.5,
		"max_pan":    2332.5,
		"start_pan":  1166.2,
	},
}

# Pan speed in pixels per second
const PAN_SPEED       : float = 800.0
# Edge zone: fraction of screen width that triggers pan
const PAN_EDGE_FRAC   : float = 0.20
# Edge zone in pixels
const PAN_EDGE_PX     : float = VIEWPORT_W * PAN_EDGE_FRAC   # 216px

# =====================================================
#  STATE
# =====================================================

var current_room  : String = "papyrus_room"
var _pan_offset   : float  = 1166.7   # starts at center
var _is_exploring : bool   = false    # pan only during explore
var _touch_x      : float  = -1.0    # current touch position

var _inventory    : Array  = []

var _flags : Dictionary = {
	"used_desktop"      : false,
	"earned_g"          : false,
	"made_pancakes"     : false,
	"has_pancakes"      : false,
	"saw_waterfall_cut" : false,
	"papyrus_warned"    : false,
	"desktop_pw_found"  : false,
}

# =====================================================
#  READY
# =====================================================
func _ready() -> void:
	# ── Wire VNEngine ──────────────────────────────────
	engine.bg_rect          = bg_rect
	engine.char_center      = char_center
	engine.char_left        = char_left
	engine.char_right       = char_right
	engine.dialog_box       = dialog_box
	engine.name_box         = name_box
	engine.name_label       = name_label
	engine.dialog_text      = dialog_text
	engine.next_arrow       = next_arrow
	engine.choice_container = choice_cont
	engine.black_screen     = black_screen
	engine.fade_player      = fade_player

	# ── Signals ────────────────────────────────────────
	engine.chapter_ended.connect(_on_chapter_ended)
	engine.chapter_event.connect(_on_chapter_event)

	# ── Restore save flags ─────────────────────────────
	_load_flags_from_save()

	# ── Init background sizing ─────────────────────────
	# BG fills full rendered width, height = 1920
	# TextureRect: expand_mode=0, stretch_mode=0 (custom size)
	_init_bg_size()
	
	# ── Initialize exploration layer safely ────────────
	_init_exploration_system()

	# ── Start in Papyrus room ──────────────────────────
	_switch_room("papyrus_room", false)

	# ── Load data + start ──────────────────────────────
	var data_obj = CHAPTER_DATA.new()
	engine.load_chapter(data_obj.DATA)
	engine.start("start")


# =====================================================
#  INITIALIZE EXPLORATION SYSTEM (SAFE)
# =====================================================
func _init_exploration_system() -> void:
	# Verify all required nodes exist, log warnings if missing
	if not is_instance_valid(explore_layer):
		push_warning("Chapter2: ExploreLayer not found in scene!")
	if not is_instance_valid(room_papyrus):
		push_warning("Chapter2: Room_PapyrusRoom not found in scene!")
	if not is_instance_valid(room_living):
		push_warning("Chapter2: Room_LivingRoom not found in scene!")
	if not is_instance_valid(room_kitchen):
		push_warning("Chapter2: Room_Kitchen not found in scene!")
	if not is_instance_valid(blizzard_fx):
		push_warning("Chapter2: BlizzardFX not found in scene!")
	if not is_instance_valid(pan_hint_left):
		push_warning("Chapter2: PanHintLeft not found in scene!")
	if not is_instance_valid(pan_hint_right):
		push_warning("Chapter2: PanHintRight not found in scene!")


# =====================================================
#  PROCESS — PAN SYSTEM
# =====================================================
func _show_yesterday_dramatic() -> void:
	"""Show 'YESTERDAY' with animated dots (3 dots fade in slowly) then auto-dismiss after 5 sec."""
	# Kill any existing tween
	if _yesterday_tween:
		_yesterday_tween.kill()
	
	# Setup black screen
	black_screen.color = Color.BLACK
	black_screen.show()
	
	# Start with empty dots
	_yesterday_dots = 0
	yesterday_label.text = "YESTERDAY"
	yesterday_label.visible = true
	
	# Create new tween for dramatic dot animation
	_yesterday_tween = create_tween()
	_yesterday_tween.set_trans(Tween.TRANS_LINEAR)
	
	# Animate three dots appearing one by one
	for i in range(3):
		_yesterday_tween.tween_callback(func(): 
			_yesterday_dots += 1
			yesterday_label.text = "YESTERDAY" + ".".repeat(_yesterday_dots)
		)
		_yesterday_tween.tween_interval(0.5)  # 0.5 sec between each dot
	
	# Hold for remaining time (5 sec total - 1.5 sec for dots = 3.5 sec more)
	_yesterday_tween.tween_interval(3.5)
	
	# Fade to black and resume engine
	_yesterday_tween.tween_callback(func():
		# Fade out black screen
		var fade_tween = create_tween()
		fade_tween.tween_property(black_screen, "color:a", 0.0, 0.5)
		fade_tween.tween_callback(func():
			black_screen.hide()
			black_screen.color = Color.BLACK  # Reset alpha for next use
			engine.resume()
		)
	)


func _process(delta: float) -> void:
	if not _is_exploring:
		return

	var pan_data : Dictionary = ROOM_PAN.get(current_room, {})
	if pan_data.is_empty():
		return

	var max_pan : float = pan_data["max_pan"]
	var moved   : bool  = false

	# ── Determine pan direction from touch/mouse ───────
	var input_x : float = _get_input_x()

	if input_x >= 0.0:
		if input_x < PAN_EDGE_PX:
			# Left edge → pan left (decrease offset)
			_pan_offset -= PAN_SPEED * delta
			moved = true
		elif input_x > (VIEWPORT_W - PAN_EDGE_PX):
			# Right edge → pan right (increase offset)
			_pan_offset += PAN_SPEED * delta
			moved = true

	# ── Clamp to valid range ───────────────────────────
	_pan_offset = clamp(_pan_offset, 0.0, max_pan)

	# ── Apply to background + hotspot container ────────
	if moved:
		_apply_pan()

	# ── Show/hide pan hint arrows ──────────────────────
	_update_pan_hints(max_pan)


func _get_input_x() -> float:
	# Mobile touch first, fall back to mouse
	if Input.is_action_pressed("ui_touch") or _touch_x >= 0.0:
		return _touch_x
	# Mouse (editor/desktop testing)
	return get_viewport().get_mouse_position().x


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_touch_x = event.position.x
		else:
			_touch_x = -1.0
	elif event is InputEventScreenDrag:
		_touch_x = event.position.x


# =====================================================
#  PAN APPLICATION
# =====================================================

func _init_bg_size() -> void:
	# Set bg_rect to custom size matching rendered dimensions
	# so it doesn't stretch to fill anchors
	var pan_data : Dictionary = ROOM_PAN.get(current_room, ROOM_PAN["papyrus_room"])
	bg_rect.custom_minimum_size = Vector2(pan_data["rendered_w"], VIEWPORT_H)
	bg_rect.size                = Vector2(pan_data["rendered_w"], VIEWPORT_H)
	bg_rect.stretch_mode        = TextureRect.STRETCH_SCALE
	bg_rect.expand_mode         = TextureRect.EXPAND_IGNORE_SIZE
	bg_rect.position            = Vector2(-_pan_offset, 0)


func _apply_pan() -> void:
	# Move background
	bg_rect.position.x = -_pan_offset

	# Move ALL hotspot containers in ExploreLayer with it
	# Each room Control sits at position.x = -pan_offset
	# so hotspot pixel positions are in image space directly
	room_papyrus.position.x = -_pan_offset
	room_living.position.x  = -_pan_offset
	room_kitchen.position.x = -_pan_offset


func _update_pan_hints(max_pan: float) -> void:
	if not is_instance_valid(pan_hint_left) or not is_instance_valid(pan_hint_right):
		return
	pan_hint_left.visible  = (_pan_offset > 10.0)
	pan_hint_right.visible = (_pan_offset < max_pan - 10.0)


func _set_pan_for_room(room_id: String, animate: bool = true) -> void:
	var pan_data : Dictionary = ROOM_PAN.get(room_id, {})
	if pan_data.is_empty():
		return

	var target : float = pan_data["start_pan"]

	# Resize BG for new room's scale
	bg_rect.custom_minimum_size = Vector2(pan_data["rendered_w"], VIEWPORT_H)
	bg_rect.size                = Vector2(pan_data["rendered_w"], VIEWPORT_H)

	if animate:
		var tw := create_tween()
		tw.tween_method(_tween_pan, _pan_offset, target, 0.4)
	else:
		_pan_offset = target
		_apply_pan()


func _tween_pan(value: float) -> void:
	_pan_offset = value
	_apply_pan()


# =====================================================
#  EXPLORE MODE TOGGLE
#  Call _set_explore(true) when story enters a room
#  Call _set_explore(false) when VNEngine takes over
# =====================================================
func _set_explore(on: bool) -> void:
	_is_exploring = on
	explore_layer.visible = on
	if is_instance_valid(pan_hint_left):
		pan_hint_left.visible  = on
	if is_instance_valid(pan_hint_right):
		pan_hint_right.visible = on


# =====================================================
#  CHAPTER ENDED
# =====================================================
func _on_chapter_ended(next_chapter: int) -> void:
	if has_node("/root/AudioM"):
		get_node("/root/AudioM").fade_out_bgm(0.5)
	fade_player.play("FadeOut")
	await fade_player.animation_finished
	var next_scene := "res://scenes/chapter%d.tscn" % next_chapter
	if ResourceLoader.exists(next_scene):
		get_tree().change_scene_to_file(next_scene)
	else:
		get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


# =====================================================
#  CHAPTER EVENTS
# =====================================================
func _on_chapter_event(event_id: String) -> void:
	match event_id:

		# ── Room transitions ───────────────────────────
		"enter_papyrus_room":
			_switch_room("papyrus_room")
			engine.resume()

		"enter_living_room":
			_switch_room("living_room")
			engine.resume()

		"enter_kitchen":
			_switch_room("kitchen")
			engine.resume()

		# ── Explore mode on/off ────────────────────────
		"explore_start":
			_set_explore(true)
			engine.resume()

		"explore_end":
			_set_explore(false)
			engine.resume()

		# ── Bonedows / desktop flags ───────────────────
		"bonedows_open":
			_set_explore(false)
			_load_bonedows()

		"waterfall_cutscene":
			# Cutscene stack keeps the chapter paused while the flashback runs.
			if engine.has_method("push_scene"):
				engine.push_scene("waterfall_scene")
			else:
				engine.jump_to("waterfall_scene")

		"flag_password_found":
			_flags["desktop_pw_found"] = true
			_save_flag("desktop_pw_found", true)
			engine.resume()

		"ingredients_collected":
			_flags["ingredients_collected"] = true
			_save_flag("ingredients_collected", true)
			engine.resume()

		"fridge_dim":
			engine.resume()

		"fridge_stare_tick_1":
			engine.resume()

		"fridge_stare_tick_2":
			engine.resume()

		"pancakes_in_inventory":
			_flags["made_pancakes"] = true
			_flags["has_pancakes"] = true
			_save_flag("made_pancakes", true)
			_save_flag("has_pancakes", true)
			engine.resume()

		"waterfall_done":
			_flags["saw_waterfall_cut"] = true
			_save_flag("saw_waterfall_cut", true)
			if engine.has_method("return_from_cutscene"):
				engine.return_from_cutscene()
			else:
				engine.resume()

		"yesterday_title":
			# Title card hook for the Waterfall flashback.
			# Show dramatic "YESTERDAY" with animated dots and 5-sec auto-dismiss
			if is_instance_valid(yesterday_label):
				_show_yesterday_dramatic()
			# Engine stays paused; we resume after the timer

		# ── Chapter end ────────────────────────────────
		"chapter_end":
			_set_explore(false)
			_on_chapter_ended(3)


		# ── Desktop used ───────────────────────────────
		"desktop_used":
			_flags["used_desktop"] = true
			_save_flag("used_desktop", true)
			engine.resume()

		# ── G earned (quiz solved) ─────────────────────
		"g_earned":
			_flags["earned_g"] = true
			_save_flag("earned_g", true)
			engine.resume()

		# ── Blizzard ───────────────────────────────────
		"blizzard_start":
			_set_blizzard(true)
			engine.resume()

		"blizzard_stop":
			_set_blizzard(false)
			engine.resume()

		# ── Screen shake ───────────────────────────────
		"screen_shake":
			await _do_screen_shake(0.3, 8.0)
			engine.resume()

		_:
			engine.resume()


# =====================================================
#  ROOM SYSTEM
# =====================================================
func _switch_room(room_id: String, animate: bool = true) -> void:
	if animate:
		fade_player.play("FadeOut")
		await fade_player.animation_finished

	current_room = room_id

	# Safe visibility updates - only if nodes exist
	if is_instance_valid(room_papyrus):
		room_papyrus.visible = (room_id == "papyrus_room")
	if is_instance_valid(room_living):
		room_living.visible  = (room_id == "living_room")
	if is_instance_valid(room_kitchen):
		room_kitchen.visible = (room_id == "kitchen")

	# Reset pan to room's default start position
	_set_pan_for_room(room_id, false)

	if animate:
		fade_player.play("FadeIn")


# =====================================================
#  INVENTORY STUB
# =====================================================
func _add_item(id: String, item_name: String, desc: String) -> void:
	for item in _inventory:
		if item["id"] == id:
			return
	_inventory.append({ "id": id, "name": item_name, "desc": desc })
	_save_flag("inv_" + id, true)

func has_item(id: String) -> bool:
	for item in _inventory:
		if item["id"] == id:
			return true
	return false

func remove_item(id: String) -> void:
	for i in range(_inventory.size() - 1, -1, -1):
		if _inventory[i]["id"] == id:
			_inventory.remove_at(i)
			_save_flag("inv_" + id, false)
			break


# =====================================================
#  BLIZZARD FX
# =====================================================
func _set_blizzard(on: bool) -> void:
	if blizzard_fx == null:
		return
	if on:
		blizzard_fx.show()
		if blizzard_fx.has_method("restart"):
			blizzard_fx.restart()
	else:
		blizzard_fx.hide()


# =====================================================
#  WATERFALL CUTSCENE
# =====================================================
# =====================================================
#  COOKING SCENE
# =====================================================

func _load_bonedows() -> void:
	var scene_path := "res://scenes/Bonedows/bonedows.tscn"
	var scene = load(scene_path)
	if scene == null:
		push_error("Chapter2: Bonedows scene not found: " + scene_path)
		cutscene_layer.visible = false
		engine.resume()
		return

	if is_instance_valid(bonedows_inst):
		bonedows_inst.queue_free()
		bonedows_inst = null

	bonedows_inst = scene.instantiate()
	cutscene_layer.visible = true
	cutscene_layer.add_child(bonedows_inst)

	if bonedows_inst.has_signal("bonedows_closed"):
		bonedows_inst.bonedows_closed.connect(_on_bonedows_closed)
	else:
		push_error("Chapter2: Bonedows scene has no bonedows_closed signal")
		bonedows_inst.queue_free()
		bonedows_inst = null
		cutscene_layer.visible = false
		engine.resume()


func _on_bonedows_closed() -> void:
	if is_instance_valid(bonedows_inst):
		bonedows_inst.queue_free()
	bonedows_inst = null
	cutscene_layer.visible = false
	engine.resume()


# =====================================================
#  SCREEN SHAKE
# =====================================================
func _do_screen_shake(duration: float, strength: float) -> void:
	var original_pos : Vector2 = Vector2(-_pan_offset, 0)
	var elapsed      : float   = 0.0

	while elapsed < duration:
		var dt : float = get_process_delta_time()
		var offset := Vector2(
			randf_range(-strength, strength),
			randf_range(-strength, strength)
		)
		bg_rect.position = original_pos + offset
		elapsed += dt
		await get_tree().process_frame

	bg_rect.position = original_pos


# =====================================================
#  SAVE / FLAG HELPERS
# =====================================================
func _load_flags_from_save() -> void:
	var sav = get_node_or_null("/root/SavM")
	if sav == null:
		return
	for key in _flags.keys():
		if sav.data.has(key):
			_flags[key] = sav.data[key]
	if sav.data.get("inv_pancakes", false):
		_add_item("pancakes", "Papyrus's Pancakes",
			"Surprisingly fluffy. You weren't expecting that.")

func _save_flag(key: String, value) -> void:
	var sav = get_node_or_null("/root/SavM")
	if sav:
		sav.data[key] = value


# =====================================================
#  PUBLIC HELPERS
# =====================================================
func player_used_desktop() -> bool:
	return _flags.get("used_desktop", false)

func player_earned_g() -> bool:
	return _flags.get("earned_g", false)

# Returns current pan offset (useful for cutscene/event debugging)
func get_pan_offset() -> float:
	return _pan_offset
